package com.bignerdranch.android.tingle;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

/**
 * This class represents a fragment used to display all items in list.
 * The fragment is hosted by the activity TingleActivity.
 */
public class ListFragment extends Fragment {

    private Button mBackButton;
    private ListView mListView;
    private ThingsDB mThingsDB;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // setContentView(R.layout.activity_list);

        mThingsDB = ThingsDB.get(this.getContext()); // Correct?

    }

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState)
    {
        View v = inflater.inflate(R.layout.fragment_list, container, false);
        setButtons(v);
        setListView(v);
        return v;
    }



    // Redirect back to main page (TingleActivity)
    private void setButtons(View view)
    {
        mBackButton = (Button) view.findViewById(R.id.backButton);
        mBackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), TingleActivity.class); // getActivity represents current context of Fragment
                startActivity(i);
            }
        });
    }

    // Bind list and items in
    private void setListView(View view)
    {
        mListView = (ListView) view.findViewById(R.id.list_view);

        // Adapter used to bind together list and its items in the ListActivity
        final ArrayAdapter adapter = new ArrayAdapter(getActivity().getApplicationContext(), R.layout.rowitem, R.id.row_item, mThingsDB.getThingsDB().toArray()); // Context, layout and how items should be visualised

        mListView.setAdapter(adapter);
    }

}
