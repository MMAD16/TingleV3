package com.bignerdranch.android.tingle;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class ListActivity extends AppCompatActivity {

    private Button mBackButton;
    private ListView mListView;
    private ThingsDB mThingsDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        mThingsDB = ThingsDB.get(this);

        setButtons();
        setListView();
    }

    private void setButtons()
    {
        mBackButton = (Button) findViewById(R.id.backButton);
        mBackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ListActivity.this, TingleActivity.class);
                startActivity(i);
            }
        });
    }

    private void setListView()
    {
        mListView = (ListView) findViewById(R.id.list_view);

        // Adapter used to bind together list and its items in the ListActivity
        final ArrayAdapter adapter = new ArrayAdapter(getApplicationContext(), R.layout.rowitem, R.id.row_item, mThingsDB.getThingsDB().toArray()); // Context, layout and how items should be visualised

        mListView.setAdapter(adapter);
    }
}
