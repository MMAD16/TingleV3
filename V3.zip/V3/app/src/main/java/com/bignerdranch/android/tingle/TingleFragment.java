package com.bignerdranch.android.tingle;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by TVANO on 23/02/16.
 */
public class TingleFragment extends Fragment {

    // GUI variables
    private Button addThing;
    private TextView lastAdded;
    private TextView newWhat, newWhere;
    private Button mListButton;

    // Database
    private static ThingsDB thingsDB;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // setContentView(R.layout.activity_tingle);

        thingsDB = ThingsDB.get(this.getContext());

    }

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState)
    {
        View v = inflater.inflate(R.layout.fragment_tingle, container, false);

        //Accessing GUI element
        lastAdded= (TextView) v.findViewById(R.id.last_thing);
        updateUI();

        // Button
        addThing = (Button) v.findViewById(R.id.add_button);

        // Text fields for describing a thing
        newWhat= (TextView) v.findViewById(R.id.what_text);
        newWhere = (TextView) v.findViewById(R.id.where_text);

        // view products click event
        addThing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((newWhat.getText().length() > 0) && (newWhere.getText().length() > 0 ))
                {
                    thingsDB.addThing(
                            new Thing( newWhat.getText().toString(),
                                    newWhere.getText().toString()));
                    newWhat.setText("");
                    newWhere.setText("");
                    updateUI();
                }
            }
        });

        mListButton = (Button) v.findViewById(R.id.item_list_button);
        mListButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), ListActivity.class);
                startActivity(i);
            }
        });

        return v;
    }

    private void updateUI() {
        int size = thingsDB.size();
        if (size > 0 )
        {
            lastAdded.setText(thingsDB.get(size-1).toString());
        }
    }

}
